#include <graphics.h>
#include<iostream>
#include <stdlib.h>
using namespace std;
class point{
public :
int x,y;
};

class poly{

private :
	point p[20];
	int inter[20];
	int v, xmin,xmax,ymin,ymax,x,y;
public:
	int c;
	void read();
	void calculate();
	void display();
	void init(float);
	void sort(int);
};
void poly:: read(){
 int i;
v=4;
p[0].x=50;p[0].y=50;p[1].x=50;p[1].y=200;p[2].x=200;p[2].y=200;
	p[3].x=200;p[3].y=50;
        p[4].x=p[0].x;
        p[4].y=p[0].y;
xmin=xmax=p[0].x;
ymin=ymax=p[0].y;
}

void poly:: calculate(){
for(int i=0;i<v;++i){
if(p[i].x<xmin) xmin=p[i].x;
if(p[i].x>xmax) xmax=p[i].x;
if(p[i].y<ymin) ymin=p[i].y;
if(p[i].y>ymax) ymax=p[i].y;
}
}

void poly :: display(){
float s=ymin+0.01; delay(100);
cleardevice();
while(s<=ymax){
init(s);sort(s);
s++;
}
}

void poly:: init(float z){
int x1,x2,y1,y2,temp;
c=0;
for(int i=0;i<v;++i){
x1=p[i].x;y1=p[i].y;
x2=p[i+1].x;y2=p[i+1].y;
if(y1>y2){
temp=x1;
x1=x2;x2=temp;
temp=y1;
y1=y2;y2=temp;
}
if(z>=y1 && z<=y2){
if(y1==y2) x=x1;
else
x=x1+((z-y1)*(x2-x1))/(y2-y1);
if(x>=xmin && x<=xmax)
inter[c++]=x;
}
}
}

void poly:: sort(int z){
int temp,j,i;
        for(i=0;i<v;i++){
            line(p[i].x,p[i].y,p[i+1].x,p[i+1].y); // used to make hollow outlines of a polygon
        }
        delay(100);
        for(i=0; i<c;i+=2){
        delay(100);
        line(inter[i],z,inter[i+1],z);//Used to fill the polygon
        }
}

int main(){
 int gd=DETECT,gm;
    initgraph(&gd,&gm,NULL);
    poly x;
    x.read();
    x.calculate();
    cleardevice();
    setcolor(15);
    x.display();
    closegraph(); 
delay(1000);
closegraph();
} 
