#include<stdio.h>
#include<math.h>
#include<graphics.h>



void ellipseMidPoint(int xc, int yc, int ra, int rb){ 
float pi=3.14159,t=pi/180,d,x,y;
int i=0;
while(i<360){
d=t*i;
x=ra*sin(d),y=rb*cos(d);
putpixel(xc+x,yc+y,RED);
//putpixel(xc-x,yc+y,WHITE);
i++;
}
         delay(50); 
 }  
int main() { 
    int xc = 200, yc = 200, ra = 100,rb=50; 
    int gd = DETECT, gm; 
    initgraph(&gd, &gm,NULL);  
    ellipseMidPoint(xc, yc, ra, rb); 
	delay(4000); 
    return 0; 
} 
