#include<stdio.h>
#include<graphics.h>
/*
int mat[3][3]={{1,0,20},{0,1,10},{0,0,1}};
int result[3];
int* translate(int x[3]){
  int j,i,temp;
for(i=0;i<3;++i){
for(j=0;j<3;++j)
 temp=x[j]*(mat[i][j]);
result[i]=temp;
}
return result;
}
*/
int main(){
int gd=DETECT,gm;
initgraph(&gd,&gm,NULL);
int x0=5,y0=8,x1=120,y1=180,dx=x1-x0,dy=y1-y0;
line(x0,y0,x1,y1);
//line(x0+2,y0+1,x1+2,y1+1);


float Xinc,Yinc,X=x0,Y=y0,steps;
steps=(dx>dy)?dx:dy;
int i;
Xinc=dx/steps;
Yinc=dy/steps;
putpixel(X+20,Y+10,RED);
for(i=0;i<=steps;++i){
X=X+Xinc;
Y=Y+Yinc;
putpixel(X+20,Y+10,RED);
}
delay(3000);
closegraph();
return 0;
}
