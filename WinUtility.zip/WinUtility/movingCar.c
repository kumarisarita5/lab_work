#include<graphics.h>

void movingCar(){

int i,j;
for( i=0;i<420;i=i+10){
setcolor(5);
bar(50+i,275,150+i,400);
bar(130+i,350,210+i,400);
circle(80+i,410,10);
circle(180+i,410,10);
delay(100);
setcolor(0);

bar(50+i,275,150+i,400);
bar(130+i,350,210+i,400);
circle(80+i,410,10);
circle(180+i,410,10);

}

}

int main(){
int gd=DETECT,gm;
initgraph(&gd,&gm,NULL);
movingCar();
delay(1000);
closegraph();
return 0;

}
