#include<stdio.h>
#include<graphics.h>


int main(){
 int gd=DETECT,gm;
initgraph(&gd,&gm,NULL);
int x0=20,y0=20,x1=200,y1=100,dx=x1-x0,dy=y1-y0;
float m,X=x0,Y=y0,steps;
steps=(dx>dy)?dx:dy;
int i;
m=(float)dy/(float)dx;
if(m<=1){
for(i=0;i<steps;++i){
putpixel(X,Y,WHITE);
X=X+1;
Y=Y+m;
}
putpixel(X,Y,WHITE);
delay(5000);
}

else{
for(i=0;i<steps;++i){
putpixel(X,Y,WHITE);
X=X+1/m;
Y=Y+1;
}
putpixel(X,Y,WHITE);
delay(5000);
}
return 0;
}
