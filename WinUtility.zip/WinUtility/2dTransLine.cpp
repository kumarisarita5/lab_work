#include <graphics.h>
#include <stdlib.h>
#include <stdio.h>
#include<math.h>
int main(){
            int gd=DETECT,gm;
            initgraph(&gd,&gm,NULL);
int x1=50,y1=80,x2=100,y2=200;
int nx1t=x1+30,ny1t=y1+20,nx2t=x2+30,ny2t=y2+20;
int nx1s=x1*2,ny1s=3*y1,nx2s=x2*2,ny2s=3*y2;
int nx1r=x1*cos(0.2)+y1*sin(0.2),ny1r=-x1*sin(0.2)+y1*cos(0.2);
int nx2r=x2*cos(0.2)+y2*sin(0.2),ny2r=-x2*sin(0.2)+y2*cos(0.2);
line(x1,y1,x2,y2);
line(nx1t,ny1t,nx2t,ny2t);
line(nx1r,ny1t,nx2t,ny2t);
line(nx1s,ny1s,nx2s,ny2s);

delay(1000);
         closegraph();   
	}
