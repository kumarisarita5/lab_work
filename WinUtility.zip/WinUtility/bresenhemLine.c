#include<stdio.h>
#include<graphics.h>


int main(){
 int gd=DETECT,gm;
initgraph(&gd,&gm,NULL);
int x0=20,y0=20,x1=200,y1=100,dx=x1-x0,dy=y1-y0,p;
float X=x0,Y=y0,m=dy/dx;
p=2*dy-dx;
int i;
putpixel(X,Y,WHITE);
if(m<=1){
for(i=0;i<abs(dx);++i){
if(p<=0){
X++;
p=p+2*dy;
}
else{
X++;
Y++;
p=p+2*(dy-dx);
}
putpixel(X,Y,WHITE);
}
delay(5000);
}
else{

for(i=0;i<abs(dy);++i){
if(p<=0){
Y++;
p=p+2*dx;
}
else{
X++;
Y++;
p=p+2*(dx-dy);
}
putpixel(X,Y,WHITE);
}
delay(5000);

}
return 0;
}
