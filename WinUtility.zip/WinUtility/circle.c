#include<stdio.h>
#include<graphics.h>


int main(){
 int gd=DETECT,gm;
initgraph(&gd,&gm,NULL);
circle(200,250,50);
delay(1000);
return 0;
}
