#include<stdio.h>
#include<graphics.h>


void draw(int xc, int yc, int x, int y){
putpixel(x+xc,y+yc,WHITE);
putpixel(xc-x,y+yc,WHITE);
putpixel(x+xc,yc-y,WHITE);
putpixel(-x+xc,-y+yc,WHITE);
}
void ellipseMidPoint(int xc, int yc, int ra, int rb){ 
    int x = 0, y = rb,dx,dy; 
    float d = rb*rb-rb*ra*ra+(ra*ra*0.25); 
    draw(xc, yc, x, y); 

    while (abs(rb*rb*x)<=abs(ra*ra*y)){ 
        x++; 
        if (d < 0){ 
            d = d +(1+ 2*x)*rb*rb; 
        } 
        else{
	y--;
            d = d +(1+ 2*x)*rb*rb-2*y*ra*ra;
	} 
        draw(xc, yc, x, y); 
        delay(50); 
    } 
float d2=(x+0.5)*(x+0.5)*rb*rb+(y-1)*(y-1)*ra*ra-ra*ra*rb*rb;
	draw(xc,yc,x,y);
	while(y>=0){
	y--;
	if(d2<0){
	x++;
	d2=d2+(1-2*y)*ra*ra+2*x*rb*rb;	
	}
	else
	d2=d2+(1-2*y)*ra*ra;
	 draw(xc, yc, x, y);
         delay(50); 
} 
 }  
int main() { 
    int xc = 200, yc = 200, ra = 100,rb=50; 
    int gd = DETECT, gm; 
    initgraph(&gd, &gm, "");  
    ellipseMidPoint(xc, yc, ra, rb); 
	delay(4000); 
    return 0; 
} 
