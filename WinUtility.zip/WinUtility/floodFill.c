#include<stdio.h>
#include<graphics.h>
void floodFill(int x, int y,int new, int old){
if(getpixel(x,y)==old){
putpixel(x,y,RED);
floodFill(x+1,y,new,old);
floodFill(x-1,y,new,old);
floodFill(x,y+1,new,old);
floodFill(x,y-1,new,old);
}
//delay(10);
}


int main(){
int gd=DETECT,gm;
initgraph(&gd,&gm,NULL);
rectangle(50,50,300,300);
putpixel(51,51,RED);
floodFill(100,100,67,0);
delay(3000);
closegraph();
return 0;
}
