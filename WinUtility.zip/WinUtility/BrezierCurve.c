#include<stdio.h>
#include<graphics.h>


int main(){
 int gd=DETECT,gm;
initgraph(&gd,&gm,NULL);
int x0=100,y0=100,x1=200,y1=100,x2=400,y2=300,x3=300,y3=100;

float i=0,X,Y;
for (i=0;i<=1;i=i+0.001){
X=(1-i)*(1-i)*(1-i)*x0+3*i*(1-i)*(1-i)*x1+3*i*i*(1-i)*x2+i*i*i*x3;
Y=(1-i)*(1-i)*(1-i)*y0+3*i*(1-i)*(1-i)*y1+3*i*i*(1-i)*y2+i*i*i*y3;
putpixel(X,Y,RED);
delay(10);
}

delay(1000);
return 0;
}
