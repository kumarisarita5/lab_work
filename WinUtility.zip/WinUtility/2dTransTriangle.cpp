#include <graphics.h>
#include <stdlib.h>
#include <stdio.h>
#include<math.h>
int main()
{
            int gm;
            int gd=DETECT;
            int x1=50,x2=100,x3=75,y1=50,y2=50,y3=100,nx1t,nx2t,nx3t,ny1t,ny2t,ny3t;
            int nx1s,nx2s,nx3s,ny1s,ny2s,ny3s;
            int nx1r,nx2r,nx3r,ny1r,ny2r,ny3r;
            int sx=2,sy=2,xt=100,yt=0,r=45;
            float t;
         //   printf("\t Program for basic transactions");
           // printf("\n\t Enter the points of triangle");
         //   scanf("%d%d%d%d%d%d",&x1,&y1,&x2,&y2,&x3,&y3);
           // printf("\n 1.Transaction\n 2.Rotation\n 3.Scalling\n 4.exit");
            //printf("Enter your choice:");
            //scanf("%d",&c);
          // printf("\n Enter the translation factor");
                                    //scanf("%d%d",&xt,&yt);
                                    nx1t=x1+xt;
                                    ny1t=y1+yt;
                                    nx2t=x2+xt;
                                    ny2t=y2+yt;
                                    nx3t=x3+xt;
                                    ny3t=y3+yt;
                                    
 //printf("\n Enter the angle of rotation");
                                   // scanf("%d",&r);
                                    t=3.14*r/180;
                                    nx1r=abs(x1*cos(t)-y1*sin(t));
                                    ny1r=abs(x1*sin(t)+y1*cos(t));
                                    nx2r=abs(x2*cos(t)-y2*sin(t));
                                    ny2r=abs(x2*sin(t)+y2*cos(t));
                                    nx3r=abs(x3*cos(t)-y3*sin(t));
                                    ny3r=abs(x3*sin(t)+y3*cos(t));
                                    
//printf("\n Enter the scalling factor");
                                   // scanf("%d%d",&sx,&sy);
                                    nx1s=x1*sx;
                                    ny1s=y2*sy;
                                    nx2s=x2*sx;
                                    ny2s=y2*sy;
                                    nx3s=x3*sx;
                                    ny3s=y3*sy;

            initgraph(&gd,&gm,NULL);
            line(x1,y1,x2,y2);
            line(x2,y2,x3,y3);
            line(x3,y3,x1,y1);    
                                   line(nx1t,ny1t,nx2t,ny2t);
                                    line(nx2t,ny2t,nx3t,ny3t);
                                    line(nx3t,ny3t,nx1t,ny1t);

                                    line(nx1r,ny1r,nx2r,ny2r);
                                    line(nx2r,ny2r,nx3r,ny3r);
                                    line(nx3r,ny3r,nx1r,ny1r);
                             
                                    line(nx1s,ny1s,nx2s,ny2s);
                                    line(nx2s,ny2s,nx3s,ny3s);
                                    line(nx3s,ny3s,nx1s,ny1s);

                                    delay(10000);
                                    closegraph();
return 0;
                                    }

