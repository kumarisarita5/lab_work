#include<stdio.h>
#include<graphics.h>

void fill(int x, int y){
if(x>0 && y>0){
if(getpixel(x,y)!=WHITE && getpixel(x,y)!=RED){
putpixel(x,y,RED);
fill(x+1,y);
fill(x,y+1);
fill(x-1,y);
fill(x,y-1);
delay(10);
}

}
}

int main(){
int gd=DETECT,gm;
initgraph(&gd,&gm,NULL);
line(100,30,50,70);
line(50,70,70,70);
line(70,70,30,150);
line(30,150,150,150);
line(150,150,100,30);

//putpixel(100,100,RED);
fill(100,100);
delay(300);
closegraph();
return 0;
}
