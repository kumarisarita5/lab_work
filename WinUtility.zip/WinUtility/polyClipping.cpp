#include <bits/stdc++.h>
#include <graphics.h>
using namespace std;

int clipper[100][2];
int poly[100][2];
int extended[100][2];
int extended_size=0;
int p, c;
int ans=0;

int x_inter(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4){
	return ((x1*y2 - y1*x2) * (x3-x4) - (x1-x2) * (x3*y4 - y3*x4))/((x1-x2) * (y3-y4) - (y1-y2) * (x3-x4));  
}


int y_inter(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4){
	return ((x1*y2 - y1*x2) * (y3-y4) - (y1-y2) * (x3*y4 - y3*x4)) /((x1-x2) * (y3-y4) - (y1-y2) * (x3-x4)); 
}




void HodgemanClip(){
int i, j;
ans = p;
for(i=0;i<c-1;i++)
	line(clipper[i][0], clipper[i][1], clipper[i+1][0], clipper[i+1][1]);
line(clipper[c-1][0], clipper[c-1][1], clipper[0][0], clipper[0][1]);

setcolor(6);
for(i=0;i<p-1;i++)
	line(poly[i][0], poly[i][1], poly[i+1][0], poly[i+1][1]);
line(poly[p-1][0], poly[p-1][1], poly[0][0], poly[0][1]);
delay(3000);

for(int i=0;i<c;i++){
	int nextClip = (i+1)%c;
	int x1=clipper[i][0], y1=clipper[i][1];
	int x2=clipper[nextClip][0], y2=clipper[nextClip][1];
	
	for(j=0;j<p;j++){
		extended_size=0;
		int nextPoly = (j+1)%p;			
		int x3 = poly[j][0], y3 = poly[j][1];
		int x4 = poly[nextPoly][0], y4 = poly[nextPoly][1];
						
		int init_pos = (x2-x1) * (y3-y1) - (y2-y1) * (x3-x1);
		int fin_pos = (x2-x1) * (y4-y1) - (y2-y1) * (x4-x1);
		

		if (init_pos < 0 && fin_pos < 0) 
		{ 
			
			extended[extended_size][0] = x4; 
			extended[extended_size][1] = y4; 
			extended_size++; 
		} 

		else if (init_pos >= 0 && fin_pos < 0) 
		{ 
			
			extended[extended_size][0] = x_inter(x1, y1, x2, y2, x3, y3, x4, y4); 
			extended[extended_size][1] = y_inter(x1, y1, x2, y2, x3, y3, x4, y4); 
			extended_size++; 

			extended[extended_size][0] = x4; 
			extended[extended_size][1] = y4; 
			extended_size++; 
		} 


		else if (init_pos < 0 && fin_pos >= 0) 
		{ 
		
			extended[extended_size][0] = x_inter(x1, y1, x2, y2, x3, y3, x4, y4); 
			extended[extended_size][1] = y_inter(x1, y1, x2, y2, x3, y3, x4, y4); 
			extended_size++; 
		}

 
	   }
	
	p = extended_size;
	ans = max(ans, ans+p); 
	for (int k = 0; k < p; k++) 
	{ 
		poly[k][0] = extended[k][0]; 
		poly[k][1] = extended[k][1]; 
	} 
    }

setcolor(10);
cout<<ans<<endl;
for(i=0;i<ans-1;i++)
	line(poly[i][0], poly[i][1], poly[i+1][0], poly[i+1][1]);
line(poly[ans-1][0], poly[ans-1][1], poly[0][0], poly[0][1]);

delay(10000);
}


int main(){
int i;
cout<<"#Clipper Vertices\t";
cin>>c;
for(i=0; i<c;i++)
cin>>clipper[i][0]>>clipper[i][1];

cout<<"#Polygon Vertices\t";
cin>>p;
for(i=0; i<p;i++)
cin>>poly[i][0]>>poly[i][1];


int gd=DETECT, gm;
initgraph(&gd, &gm, NULL);
HodgemanClip();

}
