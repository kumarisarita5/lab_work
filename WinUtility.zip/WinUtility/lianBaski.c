#include<stdio.h>
#include<graphics.h>

int main(){
int gd=DETECT,gm;
initgraph(&gd,&gm,NULL);
int x1=80,y1=80,x2=120,y2,xmin,ymin,xmax,ymax,xx1,yy1,xx2,yy2;
    x1=120;
    y1=50;
    x2=300;
    y2=300;
   
    xmin=100;
    ymin=100;
    xmax=250;
    ymax=250;
float dx=x2-x1,dy=y2-y1,p[4],q[4],temp,t1,t2;
line(x1,y1,x2,y2);
rectangle(xmin,ymin,xmax,ymax);
delay(2000);
//setcolor(4);
int i;
p[0]=-dx;p[1]=dx;p[2]=-dy;p[3]=dy;
q[0]=x1-xmin;
q[1]=xmax-x1;
q[2]=y1-ymin;
q[3]=ymax-y1;
for(i=0;i<4;++i){
if(p[i]==0){
if(q[i]>=0){
if(i<2){
if(y1<ymin) y1=ymin;
if(y2>ymax) y2=ymax;
}
if(i>1){
if(x1<xmin) x1=xmin;
if(x2>xmax) x2=xmax;
}
line(x1,y1,x2,y2);
}
}
}
t1=0;
t2=1;
for(i=0;i<4;++i){
temp=q[i]/p[i];
if(p[i]<0){
if(t1<=temp) t1=temp;
}
else{
if(t2>temp) t2=temp;
}
}
cleardevice();
rectangle(xmin,ymin,xmax,ymax);
if(t1<t2){
xx1=x1+p[1]*t1;
xx2=x1+p[1]*t2;
yy1=y1+p[3]*t1;
yy2=y1+p[3]*t2;
line(xx1,yy1,xx2,yy2);
}
delay(3000);
closegraph();
return 0;
}
