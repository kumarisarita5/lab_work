#include<bits/stdc++.h>
#include<graphics.h>
using namespace std;

int n,x[1005],y[1005];
int vis[1005];
int r[300][300],g[300][300],b[300][300];

// Source Light
int xl =100, yl =100 ,zl=10;

// Viewer Position
int xv =100, yv =40 ,zv=100;

void normalize(vector<double> &a)
{
	double sum=0;
	for(int i=0 ; i<a.size() ; i++)
		sum += a[i]*a[i];
	sum = sqrt(sum);
	for(int i=0 ; i<a.size() ; i++)
        a[i] /= sum;
}

double dot(vector<double> a,vector<double> b)
{
	double ans=0;
	for(int i=0 ; i<3  ; i++)
		ans += a[i]*b[i];
	return ans;
}

void SCAN_LINE()
{
    int y_min=1000,y_max=0;
    for(int i=0 ; i<n ; i++)
    {
    	y_min = min(y_min,y[i]);
    	y_max = max(y_max,y[i]);
	}

	if(y_min>y_max)
    	return;

    for(int cur_y = y_min ; cur_y <= y_max ; cur_y++)
    {
    	vector<float> vt;
    	for(int i=0 ; i<n ; i++)
    	{
    		float x0 = x[i];
    		float y0 = y[i];
    		float x1 = x[(i+1)%n];
    		float y1 = y[(i+1)%n];
    		if(y0 == y1)
    			continue;
            if(vis[i])
            {
                if(y[(i+1)%n]-y[i]>0)
                    y0++;
                else
                    y0--;
            }
            float xx;
            if(x0 == x1)
            {
                xx=x0;
                if((cur_y>=y0 && cur_y<=y1) || (cur_y>=y1 && cur_y<=y0))
                {
                    vt.push_back(xx);
                }
                continue;
            }
    		xx = x1 + (cur_y-y1)*(x1-x0)/(y1-y0);

    		if((xx>=x0 && xx<=x1) || (xx>=x1 && xx<=x0))
    		{
    			vt.push_back(xx);
			}
		}

    	sort(vt.begin(),vt.end());
        for(int i=0 ; i<vt.size()-1 ; i+=2)
    	{
    		int ff = vt[i];
    		int ss = vt[i+1];

    		for(int j = ff ; j <= ss ; j++)
    		{
    			double xx = j;
    			double yy = cur_y;

    			vector<double> light;
    			light.push_back(xl-xx);
    			light.push_back(yl-yy);
    			light.push_back(zl-0);
    			normalize(light);

    			vector<double> view;
    			view.push_back(xv-xx);
    			view.push_back(yv-yy);
    			view.push_back(zv-0);

    			vector<double> normal;
    			normal.push_back(0);
    			normal.push_back(0);
    			normal.push_back(1);

    			normalize(light);
    			normalize(view);

    			double cur_int = 0;
    			// Ambient => FIXED
    			cur_int += 20.0;

    			// Diffused
    			double ct1 = dot(light,normal);
    			cur_int += 40.0*ct1;

    			// Specular
    			vector<double> half(3);
    			for(int pp=0 ; pp<3 ; pp++)
    			{
    				half[pp] = light[pp]+view[pp];
				}
				normalize(half);

				double ct2 = dot(half,normal);
    			cur_int += 200.0*pow(ct2,4);

                r[j][cur_y] = int(cur_int);
    			putpixel(j,cur_y,WHITE);
			}
		}
	}
}

int main()
{
    /*
    Input
    3
    20 20
    260 280
    180 20
    */

    int gd=DETECT,gm;
    initgraph(&gd, &gm,"");
    cout<<"Enter no of points : ";
    cin>>n;
    cout<<"Enter points in clockwise direction"<<endl;

    for(int i=0 ; i<n ; i++)
        cin>>x[i]>>y[i];

    for(int i=0 ; i<n ; i++)
        line(x[i],y[i],x[(i+1)%n],y[(i+1)%n]);

    for(int i=0 ; i<n ; i++)
    {
        if((y[(i-1+n)%n]-y[i])*(y[(i+1)%n]-y[i])<=0)
            vis[i]=true;
    }
	SCAN_LINE();


	ofstream op("brute_gourad.ppm");
	op<<"P3"<<endl;
	op<<"300 300"<<endl;
	op<<"255"<<endl;

	int n1,n2;
    for (int i=0;i<300;i++)
    {
        for (int j=0;j<300;j++)
        {
            op<<r[i][j]<<" "<<g[i][j]<<" "<<b[i][j]<<"\t";
        }
        op<<endl;
    }
    op.close();

    getch();
    closegraph();
    return 0;
}


