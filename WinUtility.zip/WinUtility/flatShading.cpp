#include<bits/stdc++.h>
#include<stdlib.h>
//#include<cstring.h>

bool model(string fieval,vector<float>&vertices,vector<int>&indices){
string face;
string dataline,linechar;
vertices clear();indices_clear();
object.open(filename);
while(object>>line_char){
if(line_char=="V"){
for(int i=0;i<3;i++)
object>>point;
}
}
for(int i=0;i<indices.size();i++){
vertices.push_back(localvertices[i*3]);
vertices.push_back(localvertices[i*3+1]);
vertices.push_back(localvertices[i*3+2]);
vertices.push_back(localNormals[i*3]);
vertices.push_back(localNormals[i*3+1]);
vertices.push_back(localNormals[i*3+2]);
}
for(int k=0;k<3;i++){
bar3d(vertices.x1,vertices.y1,vertices.x2,vertices.y2,8,1);
indices.push_back(ind-1);
getline(object,face,11);
}
return true;
}

int main(){
int x[4],y[4],px,py,i,n;
double t;scnf("%d",&n);
for(i=0;i<n;i++)
 scanf("%d%d",&x[i],&y[i]);
imat=mem_alloc(imat,r,c);
for(i=0;i<r;i++){
for(j=0;j<c;j++){
fscanf(fp,"%d",&imat[i][j]);
}
}
imat=(int **)malloc(r*sizeof(int *));
for(i=0;i<r;i++)
imat[i]=0;
for(i=0;i<r;i++){
for(j=0;j<c;j++){
imat[i][j]=0;
return imat;
}
}
int h,k;
FILE *fp1;
fp1=fopen("out_image.pgm","wt");
fputs(s1,fp1);fputs(s2,fp1);
fprintf(fp1,"%d%d\n%d",c,r,max_pixel);
for(k=0;k<r;k++)
for(h=0;h<c;h++)
fprintf(fp1,"\n%d",imat[k][h]);
return 0;
}
