#include<stdio.h>
#include<graphics.h>

/*
void drawCircle(int xc, int yc, int x, int y){
putpixel(x+xc,y+yc,WHITE);
putpixel(-x+xc,y+yc,WHITE);
putpixel(x+xc,-y+yc,WHITE);
putpixel(-x+xc,-y+yc,WHITE);
putpixel(xc+y,yc+x,WHITE);
putpixel(xc-y,yc+x,WHITE);
putpixel(xc+y,yc-x,WHITE);
putpixel(xc-y,yc-x,WHITE);
}
*/
void drawCircle(int xc, int yc, int x, int y) 
{ 
    putpixel(xc+x, yc+y, RED); 
    putpixel(xc-x, yc+y, RED); 
    putpixel(xc+x, yc-y, RED); 
    putpixel(xc-x, yc-y, RED); 
    putpixel(xc+y, yc+x, RED); 
    putpixel(xc-y, yc+x, RED); 
    putpixel(xc+y, yc-x, RED); 
    putpixel(xc-y, yc-x, RED); 
} 

void circleMidPoint(int xc, int yc, int r) 
{ 
    int x = 0, y = r; 
    int d = 5/4- r; 
    drawCircle(xc, yc, x, y); 
    while (y >= x){ 
        x++; 
        if (d > 0){ 
            y--;  
            d = d + 2*x-2*y+1; 
        } 
        else
            d = d+2*x+1; 
        drawCircle(xc, yc, x, y); 
        delay(50); 
    } 
} 
   
int main() 
{ 
    int xc = 100, yc = 100, r = 40; 
    int gd = DETECT, gm; 
    initgraph(&gd, &gm, "");  
    circleMidPoint(xc, yc, r);  
    return 0; 
} 
