//#include<iostream.h>
#include<stdio.h>
#include<stdlib.h>
#include<graphics.h>
#include<math.h>
//using namespace std;
const int INSIDE =0;
const int LEFT =1;
const int RIGHT= 2;
const int TOP =4;
const int BOTTOM= 8;
const int xmax = 100;
const int ymax = 80;
const int xmin = 40;
const int ymin = 40;

int computeCode(double x1, double y1){
int code=INSIDE;
if(x1<xmin)code|=LEFT;
else if(x1>xmax) code|=RIGHT;
if(y1<ymin) code|=BOTTOM;
else if(y1>ymax) code|=TOP;
return code;
}

void cohenSutherland(double x1, double y1, double x2, double y2){
int accept=0;
int code1=computeCode(x1,y1),code_out;
int code2=computeCode(x2,y2);
double x,y;
while(1){
if((code1==0) && (code2==0)){
accept =1;
break;
}
else if(code1 && code2) break;
else {
if(code1!=0) code_out=code1;
else code_out=code2;
if(code_out && TOP){
x=x1+(ymax-y1)*(x2-x1)/(y2-y1);
y=ymax;
}
else if(code_out && BOTTOM){
x=x1+(ymin-y1)*(x2-x1)/(y2-y1);
y=ymin;
}
else if(code_out && LEFT){
y=y1+(xmin-x1)*(y2-y1)/(x2-x1);
x=xmin;
}
else if(code_out && RIGHT){
y=y1+(xmax-x1)*(y2-y1)/(x2-x1);
x=xmax;
}
if(code_out==code1){
x1=x;
y1=y;
code1=computeCode(x,y1);
}
else if(code_out==code2){
x2=x;
y2=y;
code2=computeCode(x2,y2);
}

}
}
if(accept)
line(x1,y1,x2,y2);

}

int main(){
    int i,gd=DETECT,gm;
    int x1,y1,x2,y2,xmin,xmax,ymin,ymax,xx1,xx2,yy1,yy2,dx,dy;
    x1=120;
    y1=50;
    x2=300;
    y2=300;
   
    xmin=100;
    ymin=100;
    xmax=250;
    ymax=250;
    initgraph(&gd,&gm,NULL);
    rectangle(xmin,ymin,xmax,ymax);
    line(x1,y1,x2,y2);
    delay(1000);
    cleardevice();
rectangle(xmin,ymin,xmax,ymax);
   cohenSutherland(x1,x2,y1,y2);
    delay(5000);
    closegraph();
}

