#include<stdio.h>
#include<graphics.h>

int main(){
 int gd=DETECT,gm;
initgraph(&gd,&gm,NULL);
int xc=100,yc=100,r=40,p=5/4-r,x=0,y=r;
putpixel(x+xc,y+yc,WHITE);
if(r>0){
putpixel(x+xc,-y+yc,WHITE);
putpixel(xc+y,yc+x,WHITE);
putpixel(xc-y,yc+x,WHITE);
}
while(x<=y){
x++;
if(p<0){
p=p+2*x+1;
}
else{
y--;
p=p+2*x+1-2*y;
}

putpixel(x+xc,y+yc,WHITE);
putpixel(-x+xc,y+yc,WHITE);
putpixel(x+xc,-y+yc,WHITE);
putpixel(-x+xc,-y+yc,WHITE);
if(x!=y){

putpixel(xc+y,yc+x,WHITE);
putpixel(xc-y,yc+x,WHITE);
putpixel(xc+y,yc-x,WHITE);
putpixel(xc-y,yc-x,WHITE);
}

//circle(xc,yc,r);
delay(50);
}
//circle(xc,yc,r);
delay(5000);
return 0;
}
