#include<graphics.h>

void movingBall(){

int i=400;
while( i>0){
setcolor(5);
circle(80,410-i,10);
delay(100);

setcolor(0);
circle(80,410-i,10);

i=i-10;
if(i<20){
while( i<400){
setcolor(5);
circle(80,410+i,10);
delay(100);
setcolor(0);
circle(80,410+i,10);
//delay(100);
i=i+10;
}
}
}

}

int main(){
int gd=DETECT,gm;
initgraph(&gd,&gm,NULL);
movingBall();
delay(1000);
closegraph();
return 0;

}
